package edu.sm.controller;

import edu.sm.app.dto.ChatMessage;
import edu.sm.app.dto.ChatWaitSession;
import edu.sm.app.msg.Msg;
import edu.sm.app.service.ChatMessageService;
import edu.sm.app.service.ChatWaitSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.util.Date;

@Slf4j
@Controller
@RequiredArgsConstructor
public class AdminMsgController {

    private final SimpMessagingTemplate template;
    private final ChatMessageService chatMessageService;
    private final ChatWaitSessionService chatWaitSessionService;

    @MessageMapping("/adminreceiveto")
    public void receiveto(Msg msg, SimpMessageHeaderAccessor headerAccessor) throws Exception {
        ChatMessage chatMessage = new ChatMessage(0, msg.getSendid(), msg.getReceiveid(), msg.getContent1(), new Date());
        chatMessageService.register(chatMessage);

        String senderId = msg.getSendid();
        boolean isAdmin = senderId.toLowerCase().startsWith("admin");

        if (isAdmin) {
            String targetCustId = msg.getReceiveid();
            template.convertAndSend("/adminsend/to/" + targetCustId, msg);
        } else {
            String custId = senderId;
            ChatWaitSession session = chatWaitSessionService.getByCustId(custId);
            boolean isNewOrReopened = false;

            if (session == null) {
                isNewOrReopened = true;
                session = new ChatWaitSession();
                session.setCustId(custId);
                session.setInquiryType(msg.getInquiryType());
                chatWaitSessionService.register(session);
            } else if ("CLOSED".equals(session.getStatus())) {
                isNewOrReopened = true;
                session.setStatus("WAITING");
                session.setAdminId(null);
                chatWaitSessionService.modify(session);
            }

            if (isNewOrReopened) {
                ChatWaitSession sessionToSend = chatWaitSessionService.getByCustId(custId);
                template.convertAndSend("/topic/waiting_room", sessionToSend);
            }

            ChatWaitSession currentSession = chatWaitSessionService.getByCustId(custId);
            // Defensive code: If a session has an admin, it should be ACTIVE.
            if (currentSession != null && currentSession.getAdminId() != null && "WAITING".equals(currentSession.getStatus())) {
                log.info("Session for " + custId + " has admin but is WAITING. Forcibly activating.");
                currentSession.setStatus("ACTIVE");
                chatWaitSessionService.modify(currentSession);
            }

            if (currentSession != null && currentSession.getAdminId() != null && "ACTIVE".equals(currentSession.getStatus())) {
                template.convertAndSend("/adminsend/to/" + currentSession.getAdminId(), msg);
            } else {
                template.convertAndSend("/adminsend/to/admin", msg);
            }
        }
    }
}