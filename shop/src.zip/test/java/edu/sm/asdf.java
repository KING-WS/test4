package edu.sm;

public class asdf{



    public static void main(String[] args) {
        int num = 0;
        int result = 0;
        out:while(num <= 3){
            for(int i = 0; i<=5;i++){
                if(i%2 == 0){
                    result += num + i;
                }
                if(i == 4){
                    break out;
                }
            }
            num++;
        }
        System.out.println(result);
    }
}
